// Estrategias de Precio (Patrón Strategy) - OCP aplicado
class PrecioGeneral {
    calcular(base) { return base; }
}

class PrecioEstudiante {
    calcular(base) { return base * 0.8; } // Descuento del 20%
}

// Factory para Comprobantes (Patrón Creacional)
class ComprobanteFactory {
    static generar(datos) {
        return `
        --- COMPROBANTE DE VENTA ---
        Función: ${datos.pelicula}
        Asiento: ${datos.asiento}
        Total Pagado: $${datos.total}
        ----------------------------`;
    }
}

// Clase de Servicio Principal
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

export class VentaService {
    async ejecutarVenta(asientoId, tipoTicket, pagoEfectivo) {
        return await prisma.$transaction(async (tx) => {
            // 1. Buscar asiento y validar estado
            const asiento = await tx.asiento.findUnique({
                where: { id: asientoId },
                include: { funcion: true }
            });

            // 2. Verificar bloqueo de 5 minutos (BR-3) 
            const ahora = new Date();
            if (asiento.estado === 'bloqueado' && (ahora - asiento.bloqueadoEn < 300000)) {
                throw new Error("El asiento está bloqueado temporalmente por otro vendedor");
            }
            if (asiento.estado === 'vendido') {
                throw new Error("El asiento ya ha sido vendido");
            }

            // 3. Aplicar Estrategia de Precio (Patrón Strategy) [cite: 35]
            const estrategia = tipoTicket === 'ESTUDIANTE' ? new PrecioEstudiante() : new PrecioGeneral();
            const totalFinal = estrategia.calcular(asiento.funcion.precioBase);

            // 4. Registrar Venta y Calcular Vuelto (Objetivo 4) [cite: 100]
            if (pagoEfectivo < totalFinal) throw new Error("Monto insuficiente");
            const vuelto = pagoEfectivo - totalFinal;

            // 5. Actualizar Asiento y Crear Comprobante [cite: 105]
            await tx.asiento.update({
                where: { id: asientoId },
                data: { estado: 'vendido', bloqueadoEn: null }
            });

            const ticketTexto = ComprobanteFactory.generar({
                pelicula: asiento.funcion.pelicula,
                asiento: asiento.codigo,
                total: totalFinal
            });

            return { ticketTexto, vuelto, totalFinal };
        });
    }
}